<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateThesisprojects extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('thesisprojects', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('title');
            $table->string('matric');
            $table->string('candidate_name');
            $table->string('grad_year');
            $table->string('abstract');
            $table->string('keyword');
            $table->string('supervisor');
            $table->string('dept');
            $table->string('faculty');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('thesisprojects');
    }
}
