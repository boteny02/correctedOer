<!-- Title Field -->
<div class="form-group">
    {!! Form::label('title', 'Title:') !!}
    <p>{!! $videos->title !!}</p>
</div>

<!-- Murl Field -->
<div class="form-group">
    {!! Form::label('murl', 'Murl:') !!}
    <p>{!! $videos->murl !!}</p>
</div>

